Plugin que permite la reproducir la lista de NerdTV en Kodi. Plugin by Ratnet.
===
Author: Ratnet
License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)