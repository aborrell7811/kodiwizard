# -*- coding: utf-8 -*-
# Module: default
# Author: Ratnet
# Created on: 30-06-2016
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urlparse import parse_qsl
import os, re, urlparse
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, urllib2, json, ssl
__url__ = sys.argv[0]
__handle__ = int(sys.argv[1])

__addon__       = xbmcaddon.Addon(id='plugin.video.live.latinchannelv2.tv')
__addondir__    = xbmc.translatePath( __addon__.getAddonInfo('profile') ) 

addon = xbmcaddon.Addon()
user = addon.getSetting("username")
password = addon.getSetting("password")

def closeSesion():
    addon = xbmcaddon.Addon()
    addon.setSetting("username","") 
    addon.setSetting("password","")
    xbmc.executebuiltin("XBMC.ActivateWindow(Home)")



VIDEOS = {}
def cargarLista(variable):
    req = urllib2.Request("http://158.69.228.135/kodi/api.php?user="+user+"&password="+password)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0')
    response = urllib2.urlopen(req)
    respuesta = response.read()
    if(str(respuesta) == "error"):
        xbmcgui.Dialog().ok("LATINCHANEL List Addon", "Error al cargar lista, verifica tus datos de sesion.")
    else:
        jsonObj=json.loads(respuesta)
        response.close()
        global VIDEOS
        VIDEOS = jsonObj
        list_categories()
        with open(__addondir__+'nerdtv.json', 'w') as fp:
            json.dump(VIDEOS, fp)


def get_categories():

    return VIDEOS.keys()

def get_videos(category):

    return VIDEOS[category]

def list_categories():

    categories = get_categories()
    for category in categories:
        list_item = xbmcgui.ListItem(label=category, thumbnailImage=VIDEOS[category]['thumb'])
        list_item.setProperty('fanart_image', VIDEOS[category]['thumb'])
        url = '{0}?action=listing&tipo={1}'.format(__url__, category)
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, isFolder=True)



    list_item = xbmcgui.ListItem(label="Cerrar Sesion")
    url = '{0}?action=closeSesion'.format(__url__, category)
    xbmcplugin.addDirectoryItem(__handle__, url, list_item, isFolder=False)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(__handle__)


def list_categories2(tipo):
    with open(__addondir__+'nerdtv.json', 'r') as fp:
        VIDEOS = json.load(fp)
    categories = VIDEOS[tipo]['videos'].keys()
    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        url = '{0}?action=videos&tipo={1}&categoria={2}'.format(__url__, tipo,category)
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, isFolder=True)
    xbmcplugin.addSortMethod(__handle__, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(__handle__)
    xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)

def list_videos(tipo,categorias):
    with open(__addondir__+'nerdtv.json', 'r') as fp:
        VIDEOS = json.load(fp)
    videos = VIDEOS[tipo]['videos'][categorias]
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['name'], thumbnailImage=video['thumb'])
        if(tipo == "PELICULAS") or (tipo == "LIVE"):
            calidad = video['calidad'];
            audio = video['audio']
            plotoutline = audio+"\n"+calidad
            plot=plotoutline+"\n"+video['sinopsis']
            list_item.setInfo(type="Video", infoLabels={"title": video['name'],"plot":plot,"playcount":0})
        if(tipo == "SERIES") or (tipo == "SERIES 24 HORAS"):
            plot = video['sinopsis']
            list_item.setInfo(type="Video", infoLabels={"title": video['name'],"plot":plot,"playcount":0})


        list_item.setArt({"thumb":video['thumb'],"poster":video['thumb'],"banner":video['thumb']})
        list_item.setProperty('IsPlayable', 'true')
        list_item.addStreamInfo('video', {'codec': 'h264'})
        url = '{0}?action=play&video={1}'.format(__url__, video['video'])
        xbmcplugin.addDirectoryItem(__handle__, url, list_item, isFolder=False)
    xbmcplugin.endOfDirectory(__handle__)
    xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
    

def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)


def router(paramstring):
    if(user == "" or password == ""):
        xbmcgui.Dialog().notification("LATINCHANNEL", "Ingresa tu usuario y contraseña.")
        xbmcaddon.Addon().openSettings()
    else:
        print "Ya configurado"
        params = dict(parse_qsl(paramstring[1:]))
        if params:
            print params
            if params['action'] == 'listing':
                list_categories2(params['tipo'])
            elif params['action'] == 'videos':
                list_videos(params['tipo'],params['categoria'])
            elif params['action'] == 'play':
                xbmc.Player().stop()
                play_video(params['video'])
            elif params['action'] == 'closeSesion':
                closeSesion()
                sys.exit()
        else:
            print "Cargando de nuevo----"
            cargarLista('primer')

if __name__ == '__main__':
    router(sys.argv[2])


